All official material on Thunderbirds Are GO!� is copyright 
by Carlton International Media Limited, and ITC Entertainment Group Limited. 
This is fan-produced material intended to promote interest 
in the shows of Gerry Anderson. 

The materials are provided as FREEWARE for your enjoyment, 
but should not be used for any commercial purpose.

Introduction
~~~~~~~~~~~~
Thank you for downloading my Thunderbirds Are GO! Fonts TTF for Windows and MAC, I hope you enjoy using it. 

Requirements
~~~~~~~~~~~~
Windows 98,2000,Me�,XP� and MAC�.

Install
~~~~~~~
1. UnZip, install into C:\windows\fonts.

Uninstall
~~~~~~~~~
Delete the .zip file.

Created By
~~~~~~~~~~
Steve (Zodiac) Ferrera
Date:12/5/2004
Filename: Anderson Thunderbirds Are GO! Fonts.zip 
Title:Thunderbirds Are GO!�
Category: TV Theme:Thunderbirds Are GO! by 2004
Archive: Fonts

Other Supermarionation Fonts are available.

Suggestions or comments send to Steve Ferrera : supercarguy@hotmail.com
ENJOY!!!


RuFus


